https://docs.google.com/forms/d/1Syw_lUwaarQMiopMQH7m3EpYswNHeEqEA19GqROF97M/edit


 <p class="texto-um-escola">A Escola Hogwarts de Magia foi criada no ano de 1876. Seu propósito é além
                de trazer encantamento ao mundo através da arte da Magia, também ensinar aos seus estudantes valores
                morais.
            </p>
            <p class="texto-dois-escola">Ela está dividida em quatro casas: Lufa-Lufa, Sonserina, Grifinória e
                Corvinal. Seus membros são escolhidos conforme seu perfil de acordo com as considerações do chapéu
                seletor.
            </p>
